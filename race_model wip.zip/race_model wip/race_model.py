import os
import torch
import torch.nn as nn
import numpy as np
from torchvision import transforms as T
from torchvision.transforms.functional import to_pil_image, to_tensor
from PIL import Image, ImageFilter
from diffusers import StableDiffusionInstructPix2PixPipeline, UniPCMultistepScheduler
from segment_anything import sam_model_registry, SamPredictor
import tkinter as tk
from tkinter import filedialog, messagebox

# ---------------------- Configuration ----------------------
device = "cuda" if torch.cuda.is_available() else "cpu"
dtype = torch.float16 if device == "cuda" else torch.float32

# ---------------------- Region Detection Module (SAM with predefined boxes) ----------------------
class RegionDetectionModule(nn.Module):
    def __init__(self):
        super().__init__()
        sam_checkpoint = "sam_vit_b.pth"
        model_type = "vit_b"
        self.sam = sam_model_registry[model_type](checkpoint=sam_checkpoint).to(device)
        self.predictor = SamPredictor(self.sam)
        self.sam.eval()

    def get_box(self, region_name, image_shape):
        h, w = image_shape
        boxes = {
            "face": [int(0.2*w), int(0.2*h), int(0.8*w), int(0.75*h)],
            "hair": [int(0.1*w), int(0.0*h), int(0.9*w), int(0.5*h)],
            "eyes": [int(0.3*w), int(0.3*h), int(0.7*w), int(0.45*h)],
            "mouth": [int(0.4*w), int(0.6*h), int(0.6*w), int(0.75*h)],
            "background": [0, 0, w, h],
        }
        return np.array([boxes.get(region_name, boxes["background"])])

    def forward(self, x, region_name):
        with torch.no_grad():
            b, c, h, w = x.shape
            assert b == 1, "SAM supports batch size 1 only"
            image = x.squeeze(0).permute(1, 2, 0).cpu().numpy()
            self.predictor.set_image(image)
            box = self.get_box(region_name, (h, w))
            masks, _, _ = self.predictor.predict(box=box, multimask_output=False)
            raw_mask = masks[0].astype(np.float32)
            # Apply blur and expand mask slightly for smoother transitions
            blurred = Image.fromarray((raw_mask * 255).astype(np.uint8)).filter(ImageFilter.GaussianBlur(radius=6))
            mask_tensor = to_tensor(blurred).unsqueeze(0).to(device)
        return mask_tensor

# ---------------------- Prompt-Based Enhancer (InstructPix2Pix with blended region) ----------------------
class PromptBasedEnhancer(nn.Module):
    def __init__(self, pipe):
        super().__init__()
        self.pipe = pipe
        self.pipe.enable_attention_slicing()

    def forward(self, image, prompt, mask=None):
        pil_image = to_pil_image(image.squeeze(0).cpu()).convert("RGB")

        result = self.pipe(
            prompt=prompt,
            image=pil_image,
            num_inference_steps=10,
            image_guidance_scale=1.0,
            guidance_scale=7.5
        ).images[0]

        result_tensor = T.ToTensor()(result).unsqueeze(0).to(image.device)
        if mask is not None:
            mask = mask.expand_as(result_tensor)
            result_tensor = mask * result_tensor + (1 - mask) * image

        return result_tensor

# ---------------------- Image Preprocessing ----------------------
def preprocess_image(image_path):
    transform = T.Compose([
        T.Resize((296, 296)),
        T.ToTensor(),
    ])
    image = Image.open(image_path).convert('RGB')
    return transform(image).unsqueeze(0).to(device)

# ---------------------- RACE Model ----------------------
class RACEModel(nn.Module):
    def __init__(self, pipe):
        super().__init__()
        self.region_detector = RegionDetectionModule()
        self.prompt_enhancer = PromptBasedEnhancer(pipe)

    def forward(self, image, prompt, region_name="face"):
        mask = self.region_detector(image, region_name)
        result = self.prompt_enhancer(image, prompt, mask)
        return result, mask

# ---------------------- GUI ----------------------
def launch_gui(model):
    def load_image():
        path = filedialog.askopenfilename(filetypes=[("Image files", "*.jpg *.jpeg *.png")])
        if path:
            image_path.set(path)
            messagebox.showinfo("Image Selected", f"Loaded: {path}")

    def run_edit():
        path = image_path.get()
        if not os.path.exists(path):
            messagebox.showerror("Error", "No image loaded!")
            return

        prompt = prompt_entry.get().strip()
        region = region_var.get()
        image_tensor = preprocess_image(path)
        edited_image, mask = model(image_tensor, prompt, region)

        to_pil_image(edited_image.squeeze(0).cpu()).save("edited_image.jpg")
        if mask is not None:
            to_pil_image(mask.squeeze(0).cpu()).save("mask_debug.jpg")

        messagebox.showinfo("Done", "Image saved as 'edited_image.jpg'")

    root = tk.Tk()
    root.title("RACE Model Editor")

    tk.Label(root, text="Prompt:").pack()
    prompt_entry = tk.Entry(root, width=60)
    prompt_entry.pack(pady=5)

    tk.Label(root, text="Region to Edit:").pack()
    region_var = tk.StringVar(value="face")
    for option in ["face", "hair", "eyes", "mouth", "background"]:
        tk.Radiobutton(root, text=option.capitalize(), variable=region_var, value=option).pack(anchor='w')

    image_path = tk.StringVar()
    tk.Button(root, text="Load Image", command=load_image).pack(pady=5)
    tk.Button(root, text="Apply Edit", command=run_edit).pack(pady=10)

    root.mainloop()

# ---------------------- Entry Point ----------------------
if __name__ == "__main__":
    try:
        pipe = StableDiffusionInstructPix2PixPipeline.from_pretrained(
            "timbrooks/instruct-pix2pix",
            torch_dtype=dtype,
            safety_checker=None
        ).to(device)

        pipe.scheduler = UniPCMultistepScheduler.from_config(pipe.scheduler.config)

        model = RACEModel(pipe).to(device)
        launch_gui(model)

    except Exception as e:
        print(f"Error: {e}")